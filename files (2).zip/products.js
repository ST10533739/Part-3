/* ==========================================================
   js/products.js  -  PRODUCTS PAGE ONLY
   - Draws the product grid
   - Category buttons + search box filter it instantly
   - Reads ?search=LUM-SRM-003 or ?category=Mask from the address
     (this is how the header search and footer links land here)
   Needs: products-data.js + common.js loaded first
   ========================================================== */

let currentCategory = 'All';
let currentQuery = '';

// Button styles (same look as the original design)
const BTN_ACTIVE = 'filter-btn px-4 py-2 rounded-full font-medium transition bg-lumiora-accent text-white';
const BTN_IDLE = 'filter-btn px-4 py-2 rounded-full font-medium transition bg-lumiora-cream hover:bg-lumiora-softPink text-lumiora-dark';

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('productSearchInput');

    // 1. Read the address (?search=...&category=...)
    const params = new URLSearchParams(window.location.search);
    const validCategories = ['All', ...new Set(PRODUCTS.map(p => p.category))];

    if (validCategories.includes(params.get('category'))) {
        currentCategory = params.get('category');
    }
    currentQuery = (params.get('search') || '').trim();
    searchInput.value = currentQuery;

    // 2. Category buttons
    document.querySelectorAll('.filter-btn').forEach(button => {
        button.addEventListener('click', () => {
            currentCategory = button.dataset.cat;
            applyFilters();
        });
    });

    // 3. Search box on this page - filters while typing
    searchInput.addEventListener('input', () => {
        currentQuery = searchInput.value.trim();
        applyFilters();
    });

    // 4. "Clear filters" button inside the empty message
    document.getElementById('productsGrid').addEventListener('click', event => {
        if (event.target.closest('[data-action="clear"]')) {
            currentCategory = 'All';
            currentQuery = '';
            searchInput.value = '';
            applyFilters();
        }
    });

    applyFilters();
});

/* The header search box (common.js) calls this when the visitor
   presses Enter while already on the Products page */
window.applyProductSearch = function (term) {
    currentQuery = term;
    currentCategory = 'All';
    document.getElementById('productSearchInput').value = term;
    applyFilters();
    document.getElementById('productsGrid').scrollIntoView({ behavior: 'smooth', block: 'start' });
};

/* ---------- Work out what to show, then draw it ---------- */
function applyFilters() {
    const results = searchProducts(currentQuery, currentCategory);

    updateFilterButtons();
    renderProductsCatalog(results);

    // "Showing 2 of 6 products"
    document.getElementById('resultCount').textContent =
        `Showing ${results.length} of ${PRODUCTS.length} products`;

    // Keep the address bar in step so the page can be bookmarked / shared
    const params = new URLSearchParams();
    if (currentQuery) params.set('search', currentQuery);
    if (currentCategory !== 'All') params.set('category', currentCategory);
    const queryString = params.toString();
    history.replaceState(null, '', window.location.pathname + (queryString ? '?' + queryString : ''));
}

function updateFilterButtons() {
    document.querySelectorAll('.filter-btn').forEach(button => {
        button.className = button.dataset.cat === currentCategory ? BTN_ACTIVE : BTN_IDLE;
    });
}

function renderProductsCatalog(list) {
    const container = document.getElementById('productsGrid');

    if (list.length === 0) {
        container.innerHTML = `
            <div class="col-span-full text-center py-12 text-gray-500">
                <i class="fas fa-search text-3xl mb-2 text-lumiora-rose"></i>
                <p class="text-sm">No products found matching your search.</p>
                <p class="text-xs mt-1">Try a product name, or a code such as <strong>LUM-SRM-003</strong>.</p>
                <button data-action="clear" class="mt-4 px-5 py-2 bg-lumiora-btn hover:bg-lumiora-btnHover text-lumiora-dark text-xs font-semibold rounded-full transition">
                    Clear filters
                </button>
            </div>
        `;
        return;
    }

    container.innerHTML = list.map(product => productCardHTML(product, true)).join('');
}

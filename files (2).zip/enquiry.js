/* ==========================================================
   js/enquiry.js  -  ENQUIRY PAGE ONLY
   This page works like a checkout / order page:
   1. Everything added with "Add to Cart" appears in the
      ORDER SUMMARY (name, code, quantity, price, total)
   2. Visitors can also add a product by typing its CODE
   3. The form is validated, then saved with the order items
      and a reference number
   Needs: products-data.js + common.js loaded first
   ========================================================== */

const ENQUIRIES_KEY = 'lumiora_enquiries';

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('enquiryForm');

    fillCodeSuggestions();
    renderOrderSummary();
    syncMessageRules();

    // Redraw the summary any time the cart changes (add, remove, +/-)
    onCartChange(() => {
        renderOrderSummary();
        syncMessageRules();
    });

    // Add-by-code box
    document.getElementById('addByCodeBtn').addEventListener('click', addProductByCode);
    document.getElementById('codeInput').addEventListener('keydown', event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            addProductByCode();
        }
    });

    // Form
    enableLiveValidation(form);
    form.addEventListener('submit', handleEnquirySubmit);

    // "Make another enquiry" button on the confirmation panel
    document.getElementById('newEnquiryBtn').addEventListener('click', () => {
        document.getElementById('enquiryConfirmation').classList.add('hidden');
        document.getElementById('enquiryFormWrap').classList.remove('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

/* ----------------------------------------------------------
   1. ORDER SUMMARY (the cart, shown like an order)
   ---------------------------------------------------------- */
function renderOrderSummary() {
    const list = document.getElementById('enquiryItems');
    const items = getCartDetailed();

    if (items.length === 0) {
        list.innerHTML = `
            <div class="text-center py-8 text-gray-400">
                <i class="fas fa-shopping-basket text-3xl mb-2 text-lumiora-rose/50"></i>
                <p class="text-sm">Your order is empty.</p>
                <a href="products.html" class="inline-block mt-3 text-xs font-semibold text-lumiora-accent hover:underline">Browse products &rarr;</a>
            </div>
        `;
    } else {
        list.innerHTML = items.map(item => `
            <div class="flex items-start space-x-3 py-3 border-b border-gray-100 last:border-0">
                <img src="${item.image}" alt="${item.name}" class="w-14 h-14 object-cover rounded-xl flex-shrink-0"
                     onerror="this.onerror=null;this.src='https://placehold.co/100x100/D89CA4/FFFFFF?text=Item'">
                <div class="flex-grow min-w-0">
                    <h4 class="text-xs font-bold text-lumiora-dark">${item.name}</h4>
                    <p class="text-[10px] text-gray-400">Code: ${item.code}</p>
                    <div class="flex items-center space-x-2 mt-1.5">
                        <button type="button" onclick="updateQuantity('${item.code}', -1)" aria-label="Decrease quantity" class="w-5 h-5 rounded-full bg-lumiora-cream text-gray-600 flex items-center justify-center text-xs font-bold">-</button>
                        <span class="text-xs font-bold">${item.qty}</span>
                        <button type="button" onclick="updateQuantity('${item.code}', 1)" aria-label="Increase quantity" class="w-5 h-5 rounded-full bg-lumiora-cream text-gray-600 flex items-center justify-center text-xs font-bold">+</button>
                        <span class="text-[10px] text-gray-400">&times; ${formatPrice(item.price)}</span>
                    </div>
                </div>
                <div class="text-right flex-shrink-0">
                    <p class="text-xs font-bold text-lumiora-accent">${formatPrice(item.lineTotal)}</p>
                    <button type="button" onclick="removeFromCart('${item.code}')" aria-label="Remove ${item.name}" class="text-gray-400 hover:text-red-500 text-xs mt-2">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Totals
    const subtotal = getCartSubtotal();
    document.getElementById('enquirySubtotal').textContent = formatPrice(subtotal);

    // Free delivery message (threshold comes from common.js)
    const note = document.getElementById('deliveryNote');
    if (items.length === 0) {
        note.textContent = `Free delivery on orders over R${FREE_DELIVERY_FROM}.`;
    } else if (subtotal >= FREE_DELIVERY_FROM) {
        note.textContent = 'You qualify for free delivery!';
    } else {
        note.textContent = `Add ${formatPrice(FREE_DELIVERY_FROM - subtotal)} more to get free delivery.`;
    }
}

/* If there are items in the order, the message box becomes optional */
function syncMessageRules() {
    const message = document.getElementById('enquiryMessage');
    const star = document.getElementById('messageStar');
    const hasItems = cart.length > 0;

    message.dataset.rules = hasItems ? 'min:10' : 'required|min:10';
    star.textContent = hasItems ? '(optional - your order is attached)' : '*';

    // If an error was showing and no longer applies, re-check it
    if (message.classList.contains('input-invalid')) validateField(message);
}

/* ----------------------------------------------------------
   2. ADD A PRODUCT BY TYPING ITS CODE
   ---------------------------------------------------------- */
function fillCodeSuggestions() {
    // Gives the code box a drop-down list of every code
    document.getElementById('codeList').innerHTML = PRODUCTS
        .map(p => `<option value="${p.code}">${p.name}</option>`)
        .join('');
}

function addProductByCode() {
    const input = document.getElementById('codeInput');
    const message = document.getElementById('codeMessage');
    const typed = input.value.trim();

    if (typed === '') {
        message.textContent = 'Type a product code first, e.g. LUM-SRM-003.';
        message.className = 'text-[11px] mt-1 text-rose-600';
        return;
    }

    // Exact code first (LUM-SRM-003 / lumsrm003), otherwise a single search match
    let product = findProduct(typed);
    if (!product) {
        const matches = searchProducts(typed);
        if (matches.length === 1) product = matches[0];
    }

    if (!product) {
        message.textContent = `No product found for "${typed}". Codes look like LUM-SRM-003.`;
        message.className = 'text-[11px] mt-1 text-rose-600';
        return;
    }

    addToCart(product.code);
    input.value = '';
    message.textContent = `Added ${product.code} - ${product.name}`;
    message.className = 'text-[11px] mt-1 text-emerald-600';
}

/* ----------------------------------------------------------
   3. SUBMIT THE ENQUIRY / ORDER
   ---------------------------------------------------------- */
function handleEnquirySubmit(event) {
    event.preventDefault();
    const form = event.target;

    if (!validateForm(form)) {
        showToast('Please fix the highlighted fields.', 'error');
        return;
    }

    // Take a snapshot of the order BEFORE the cart is cleared
    const items = getCartDetailed();
    const enquiry = {
        reference: makeReference(),
        date: new Date().toISOString(),
        name: form.elements['fullName'].value.trim(),
        email: form.elements['email'].value.trim(),
        phone: form.elements['phone'].value.trim(),
        type: form.elements['enquiryType'].value,
        message: form.elements['message'].value.trim(),
        items: items.map(i => ({ code: i.code, name: i.name, qty: i.qty, price: i.price })),
        subtotal: getCartSubtotal()
    };

    saveEnquiry(enquiry);
    showConfirmation(enquiry);

    clearCart();       // the order has been sent, so empty the bag
    form.reset();
    // reset() puts back the original look, so wipe any leftover error messages
    form.querySelectorAll('[data-rules]').forEach(field => showFieldError(field, ''));
}

function makeReference() {
    const now = new Date();
    const datePart = now.toISOString().slice(2, 10).replace(/-/g, '');   // e.g. 261102
    const randomPart = Math.floor(1000 + Math.random() * 9000);
    return `ENQ-${datePart}-${randomPart}`;
}

function saveEnquiry(enquiry) {
    try {
        const saved = JSON.parse(localStorage.getItem(ENQUIRIES_KEY) || '[]');
        saved.push(enquiry);
        localStorage.setItem(ENQUIRIES_KEY, JSON.stringify(saved));
    } catch (error) { /* storage unavailable - confirmation still shows */ }
}

function showConfirmation(enquiry) {
    document.getElementById('confRef').textContent = enquiry.reference;
    document.getElementById('confName').textContent = enquiry.name;
    document.getElementById('confEmail').textContent = enquiry.email;
    document.getElementById('confType').textContent = enquiry.type;

    const itemsBox = document.getElementById('confItems');
    if (enquiry.items.length === 0) {
        itemsBox.innerHTML = '<p class="text-xs text-gray-500">No products attached - this was a general enquiry.</p>';
    } else {
        itemsBox.innerHTML = enquiry.items.map(item => `
            <div class="flex justify-between text-xs py-1.5 border-b border-gray-100 last:border-0">
                <span>${item.qty} &times; ${item.name} <span class="text-gray-400">(${item.code})</span></span>
                <span class="font-semibold">${formatPrice(item.price * item.qty)}</span>
            </div>
        `).join('') + `
            <div class="flex justify-between text-sm font-bold text-lumiora-accent pt-2">
                <span>Total</span><span>${formatPrice(enquiry.subtotal)}</span>
            </div>`;
    }

    document.getElementById('enquiryFormWrap').classList.add('hidden');
    document.getElementById('enquiryConfirmation').classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast('Your enquiry has been received!', 'success');
}

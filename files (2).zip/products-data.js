/* ==========================================================
   js/products-data.js
   The product catalogue + search helpers.
   Loaded on: index, products, enquiry, contact
   Every product has a unique CODE (e.g. LUM-SRM-003) so the
   search bar can find it instantly by typing the code.
   ========================================================== */

const PRODUCTS = [
    {
        code: "LUM-CLN-001",
        name: "Gentle Blemish Foaming Cleanser",
        category: "Cleanser",
        price: 180,
        image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80",
        description: "Deep cleansing foam enriched with natural tea tree oil and chamomile to soothe sensitive skin while purifying pores.",
        benefits: "Removes excess oil, reduces acne flare-ups, maintains natural hydration without stripping moisture."
    },
    {
        code: "LUM-MST-002",
        name: "Daily Botanical Hydrating Moisturizer",
        category: "Moisturizer",
        price: 240,
        image: "https://images.unsplash.com/photo-1608248597261-8332570543c1?auto=format&fit=crop&w=600&q=80",
        description: "Lightweight cream formulated for day-long moisture barrier repair and softness for all South African skin types.",
        benefits: "Non-greasy, fast absorbing, locked-in hydration, suitable for sensitive daily skin routines."
    },
    {
        code: "LUM-SRM-003",
        name: "Blemish Control Clarifying Serum",
        category: "Face Serum",
        price: 320,
        image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80",
        description: "Concentrated active formula targeting dark spots, breakouts, and uneven tone for a smooth natural radiance.",
        benefits: "Fades blemish marks, shrinks visible pores, promotes uniform texture within weeks."
    },
    {
        code: "LUM-SOP-004",
        name: "Calming Rosewater Artisan Soap",
        category: "Soap",
        price: 95,
        image: "https://images.unsplash.com/photo-1607006344380-b6775a0824a7?auto=format&fit=crop&w=600&q=80",
        description: "Handcrafted natural bar soap infused with rosewater and glycerine for gentle daily face and body cleansing.",
        benefits: "Hypoallergenic, ultra-gentle, mild soothing scent, prevents skin tightness."
    },
    {
        code: "LUM-CRM-005",
        name: "Radiant Glow Night Recovery Cream",
        category: "Cream",
        price: 290,
        image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=600&q=80",
        description: "Rich overnight nourishing cream infused with botanical oils that restore cellular elasticity while you sleep.",
        benefits: "Deep night restoration, glowing morning feel, calms inflammation and redness."
    },
    {
        code: "LUM-MSK-006",
        name: "Purifying Kaolin Clay Blemish Mask",
        category: "Mask",
        price: 210,
        image: "https://images.unsplash.com/photo-1567928269937-ae146e45b428?auto=format&fit=crop&w=600&q=80",
        description: "Detoxifying weekly clay treatment designed to absorb impurities and smooth rough skin texture gently.",
        benefits: "Unclogs pores, refines skin tone, balances sebum production without over-drying."
    }
];

/* ---------- Helper: strip a code down to letters + digits ---------- */
function normaliseCode(text) {
    return String(text).toLowerCase().replace(/[^a-z0-9]/g, '');
}

/* ---------- Helper: find one product by its code ---------- */
// Accepts "LUM-SRM-003", "lum-srm-003" or even "lumsrm003"
function findProduct(code) {
    const wanted = normaliseCode(code);
    return PRODUCTS.find(p => normaliseCode(p.code) === wanted) || null;
}

/* ---------- Search ----------
   Every word the user types must match the product's name,
   code, category, description or benefits.
   Optional second argument limits the search to one category. */
function searchProducts(query, category = 'All') {
    const words = String(query).toLowerCase().trim().split(/\s+/).filter(Boolean);

    return PRODUCTS.filter(p => {
        if (category !== 'All' && p.category !== category) return false;
        if (words.length === 0) return true;

        const text = `${p.name} ${p.code} ${p.category} ${p.description} ${p.benefits}`.toLowerCase();
        const codeOnly = normaliseCode(p.code);

        // Each typed word must be found somewhere in the product
        return words.every(word => {
            const wordAsCode = normaliseCode(word);
            return text.includes(word) || (wordAsCode.length >= 2 && codeOnly.includes(wordAsCode));
        });
    });
}

/* ==========================================================
   js/common.js
   Shared code used by every page that has JavaScript
   (index, products, enquiry, contact).

   What lives here:
     1. Shopping cart (saved in localStorage so it follows the
        visitor from page to page - this is what makes the items
        show up on the Enquiry page like an order)
     2. Cart drawer, quick-view and project pop-ups
     3. Toast messages
     4. Live search box in the header (search by name OR code)
     5. Form validation helpers
     6. Newsletter sign-up
   Load order on every page:
     products-data.js -> common.js -> (page file).js
   ========================================================== */

/* ----------------------------------------------------------
   1. CART DATA
   The cart is a list like: [{ code: "LUM-SRM-003", qty: 2 }]
   We only store the code + quantity; the name, price and image
   are looked up from PRODUCTS so they are always up to date.
   ---------------------------------------------------------- */
const CART_KEY = 'lumiora_cart';
const FREE_DELIVERY_FROM = 500;      // "Free Delivery Over R500" (announcement bar)

let cart = loadCart();
const cartListeners = [];            // functions to call whenever the cart changes

function loadCart() {
    try {
        const saved = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
        if (!Array.isArray(saved)) return [];
        // Keep only lines that still match a real product
        return saved.filter(line => line && findProduct(line.code) && line.qty > 0);
    } catch (error) {
        return [];                   // storage blocked or corrupted - start empty
    }
}

function saveCart() {
    try {
        localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch (error) {
        /* storage not available - the cart simply won't persist */
    }
}

// Cart lines joined with their product details (+ line total)
function getCartDetailed() {
    return cart.map(line => {
        const product = findProduct(line.code);
        return { ...product, qty: line.qty, lineTotal: product.price * line.qty };
    });
}

function getCartCount() {
    return cart.reduce((sum, line) => sum + line.qty, 0);
}

function getCartSubtotal() {
    return getCartDetailed().reduce((sum, item) => sum + item.lineTotal, 0);
}

// Other files (e.g. enquiry.js) register here to redraw when the cart changes
function onCartChange(callback) {
    cartListeners.push(callback);
}

/* ----------------------------------------------------------
   CART ACTIONS
   ---------------------------------------------------------- */
function addToCart(code, qty = 1) {
    const product = findProduct(code);
    if (!product) return false;

    const existing = cart.find(line => line.code === product.code);
    if (existing) {
        existing.qty += qty;
    } else {
        cart.push({ code: product.code, qty: qty });
    }

    saveCart();
    updateCartUI();
    bumpCartBadge();
    showToast(`Added "${product.name}" to your order!`, 'success');
    return true;
}

function removeFromCart(code) {
    cart = cart.filter(line => line.code !== code);
    saveCart();
    updateCartUI();
}

function updateQuantity(code, change) {
    const line = cart.find(l => l.code === code);
    if (!line) return;

    line.qty += change;
    if (line.qty <= 0) {
        removeFromCart(code);
    } else {
        saveCart();
        updateCartUI();
    }
}

function clearCart() {
    cart = [];
    saveCart();
    updateCartUI();
}

/* ----------------------------------------------------------
   Redraw everything that shows the cart:
   header badge, the slide-out drawer, and any page listeners
   ---------------------------------------------------------- */
function updateCartUI() {
    // Badge on the header bag icon
    const badge = document.getElementById('cartCountBadge');
    if (badge) badge.innerText = getCartCount();

    // Slide-out drawer
    const container = document.getElementById('cartItemsContainer');
    if (container) {
        const items = getCartDetailed();

        if (items.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-400">
                    <i class="fas fa-shopping-basket text-4xl mb-3 text-lumiora-rose/50"></i>
                    <p class="text-sm">Your shopping bag is empty.</p>
                </div>
            `;
        } else {
            container.innerHTML = items.map(item => `
                <div class="flex items-center space-x-3 p-3 bg-lumiora-cream/50 rounded-2xl border border-lumiora-rose/10">
                    <img src="${item.image}" alt="${item.name}" class="w-14 h-14 object-cover rounded-xl"
                         onerror="this.onerror=null;this.src='https://placehold.co/100x100/D89CA4/FFFFFF?text=Item'">
                    <div class="flex-grow min-w-0">
                        <h4 class="text-xs font-bold text-lumiora-dark line-clamp-1">${item.name}</h4>
                        <p class="text-[10px] text-gray-400">Code: ${item.code}</p>
                        <p class="text-xs text-lumiora-accent font-semibold">${formatPrice(item.price)}</p>
                        <div class="flex items-center space-x-2 mt-1">
                            <button onclick="updateQuantity('${item.code}', -1)" aria-label="Decrease quantity" class="w-5 h-5 rounded-full bg-white text-gray-600 flex items-center justify-center text-xs shadow-sm font-bold">-</button>
                            <span class="text-xs font-bold">${item.qty}</span>
                            <button onclick="updateQuantity('${item.code}', 1)" aria-label="Increase quantity" class="w-5 h-5 rounded-full bg-white text-gray-600 flex items-center justify-center text-xs shadow-sm font-bold">+</button>
                        </div>
                    </div>
                    <button onclick="removeFromCart('${item.code}')" aria-label="Remove item" class="text-gray-400 hover:text-red-500 text-xs p-1">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `).join('');
        }

        const subtotalEl = document.getElementById('cartSubtotal');
        if (subtotalEl) subtotalEl.innerText = formatPrice(getCartSubtotal());
    }

    // Tell other files (like enquiry.js) that the cart changed
    cartListeners.forEach(callback => callback());
}

function bumpCartBadge() {
    const badge = document.getElementById('cartCountBadge');
    if (!badge) return;
    badge.classList.remove('cart-bump');
    void badge.offsetWidth;          // restart the CSS animation
    badge.classList.add('cart-bump');
}

function toggleCartDrawer() {
    document.getElementById('cartDrawer').classList.toggle('hidden');
}

// "Proceed to Checkout" -> the Enquiry page shows the full order summary
function checkoutCart() {
    if (cart.length === 0) {
        showToast('Your bag is empty - add a product first.', 'error');
        return;
    }
    if (document.body.dataset.page === 'enquiry') {
        toggleCartDrawer();
        const summary = document.getElementById('order');
        if (summary) summary.scrollIntoView({ behavior: 'smooth' });
    } else {
        window.location.href = 'enquiry.html#order';
    }
}

/* ----------------------------------------------------------
   Small formatting helpers
   ---------------------------------------------------------- */
function formatPrice(amount) {
    return 'R' + Number(amount).toFixed(2);
}

// Makes text safe to place inside innerHTML (used for anything a visitor typed)
function escapeHTML(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/* ----------------------------------------------------------
   2. PRODUCT CARD (used by the home page AND the products page)
   detailed = true  -> shows the benefits box (products page)
   ---------------------------------------------------------- */
function productCardHTML(prod, detailed = false) {
    return `
        <article class="bg-white rounded-3xl p-5 border border-lumiora-rose/20 shadow-md hover:shadow-xl transition duration-300 flex flex-col justify-between" data-code="${prod.code}">
            <div>
                <div class="relative overflow-hidden rounded-2xl ${detailed ? 'h-52' : 'h-48'} mb-4">
                    <img src="${prod.image}" alt="${prod.name}" loading="lazy"
                         class="w-full h-full object-cover transform hover:scale-105 transition duration-500"
                         onerror="this.onerror=null;this.src='https://placehold.co/400x400/D89CA4/FFFFFF?text=${encodeURIComponent(prod.name)}'">
                    <span class="absolute top-3 left-3 bg-white/90 backdrop-blur text-lumiora-accent text-[10px] font-bold px-3 py-1 rounded-full uppercase shadow-sm">${prod.category}</span>
                </div>
                <p class="text-[10px] font-semibold tracking-wider text-gray-400 mb-1">CODE: ${prod.code}</p>
                <h3 class="font-bold text-lumiora-dark text-base mb-1">${prod.name}</h3>
                <p class="text-xs text-gray-500 ${detailed ? 'mb-2' : 'line-clamp-2 mb-3'}">${prod.description}</p>
                ${detailed ? `
                <div class="bg-lumiora-cream/50 p-2.5 rounded-xl text-[11px] text-gray-600 mb-4 border border-lumiora-rose/10">
                    <strong>Benefits:</strong> ${prod.benefits}
                </div>` : ''}
            </div>
            <div>
                <div class="flex justify-between items-center mb-4">
                    <span class="text-lg font-bold text-lumiora-accent">${formatPrice(prod.price)}</span>
                    <button onclick="openQuickView('${prod.code}')" class="text-xs text-gray-500 hover:text-lumiora-dark underline">Quick View</button>
                </div>
                <button onclick="addToCart('${prod.code}')" class="w-full py-2.5 bg-lumiora-btn hover:bg-lumiora-btnHover text-lumiora-dark font-semibold text-xs rounded-xl transition shadow-sm flex items-center justify-center space-x-2">
                    <i class="fas fa-cart-plus"></i>
                    <span>Add to Cart</span>
                </button>
            </div>
        </article>
    `;
}

/* ----------------------------------------------------------
   QUICK VIEW POP-UP
   ---------------------------------------------------------- */
function openQuickView(code) {
    const product = findProduct(code);
    if (!product) return;

    document.getElementById('quickViewContent').innerHTML = `
        <div>
            <img src="${product.image}" alt="${product.name}" class="w-full h-64 object-cover rounded-2xl shadow"
                 onerror="this.onerror=null;this.src='https://placehold.co/400x400/D89CA4/FFFFFF?text=${encodeURIComponent(product.name)}'">
        </div>
        <div class="space-y-3">
            <span class="text-[10px] font-bold text-lumiora-accent uppercase bg-lumiora-softPink px-3 py-1 rounded-full">${product.category}</span>
            <p class="text-[11px] font-semibold tracking-wider text-gray-400">CODE: ${product.code}</p>
            <h3 class="text-xl font-bold text-lumiora-dark">${product.name}</h3>
            <p class="text-2xl font-bold text-lumiora-accent">${formatPrice(product.price)}</p>
            <p class="text-xs text-gray-600 leading-relaxed">${product.description}</p>
            <div class="bg-lumiora-cream p-3 rounded-xl border border-lumiora-rose/20 text-xs text-gray-700">
                <strong>Key Benefits:</strong> ${product.benefits}
            </div>
            <button onclick="addToCart('${product.code}'); closeQuickView()" class="w-full py-3 bg-lumiora-btn hover:bg-lumiora-btnHover text-lumiora-dark font-semibold text-xs rounded-xl shadow transition">
                Add to Cart Now
            </button>
        </div>
    `;
    document.getElementById('quickViewModal').classList.remove('hidden');
}

function closeQuickView() {
    document.getElementById('quickViewModal').classList.add('hidden');
}

/* ----------------------------------------------------------
   PROJECT PROPOSAL POP-UP
   Footer links go to index.html#project, so any page can open it
   ---------------------------------------------------------- */
function toggleProjectModal() {
    const modal = document.getElementById('projectModal');
    modal.classList.toggle('hidden');

    // Clear "#project" from the address so the link works again next time
    if (modal.classList.contains('hidden') && window.location.hash === '#project') {
        history.replaceState(null, '', window.location.pathname + window.location.search);
    }
}

function openProjectIfRequested() {
    if (window.location.hash === '#project') {
        document.getElementById('projectModal').classList.remove('hidden');
    }
}

/* ----------------------------------------------------------
   3. TOAST MESSAGES (little pop-up notices, bottom right)
   type: 'info' | 'success' | 'error'
   ---------------------------------------------------------- */
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const bgColor = type === 'success' ? 'bg-emerald-600' : type === 'error' ? 'bg-rose-600' : 'bg-lumiora-dark';
    const icon = type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle';

    const toast = document.createElement('div');
    toast.setAttribute('role', 'status');
    toast.className = `${bgColor} text-white text-xs px-4 py-3 rounded-xl shadow-xl flex items-center space-x-2 transition transform duration-300 pointer-events-auto`;
    toast.innerHTML = `<i class="fas ${icon} text-sm"></i><span></span>`;
    toast.querySelector('span').textContent = message;   // textContent = safe for any text

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

/* ----------------------------------------------------------
   4. HEADER SEARCH
   - As the visitor types, matching products appear straight
     away in a drop-down (works with names, benefits AND codes
     such as "LUM-SRM-003").
   - Pressing Enter shows all matches on the Products page.
   ---------------------------------------------------------- */
function initHeaderSearch() {
    const input = document.getElementById('globalSearchInput');
    const box = document.getElementById('searchResults');
    if (!input || !box) return;

    const wrap = document.getElementById('searchWrap');
    const form = input.closest('form');

    function showResults() {
        const query = input.value.trim();
        if (query === '') {
            box.classList.add('hidden');
            box.innerHTML = '';
            return;
        }

        const matches = searchProducts(query);

        if (matches.length === 0) {
            box.innerHTML = `
                <p class="text-xs text-gray-500 p-3">No products found for "<strong>${escapeHTML(query)}</strong>".
                Try a name or a code like <em>LUM-SRM-003</em>.</p>`;
        } else {
            // Show up to 5 quick matches, then a link to see everything
            box.innerHTML = matches.slice(0, 5).map(p => `
                <div class="flex items-center gap-3 p-2 rounded-xl hover:bg-lumiora-cream">
                    <button type="button" data-action="view" data-code="${p.code}" class="flex items-center gap-3 flex-grow text-left min-w-0">
                        <img src="${p.image}" alt="" class="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                             onerror="this.onerror=null;this.src='https://placehold.co/80x80/D89CA4/FFFFFF?text=L'">
                        <span class="min-w-0">
                            <span class="block text-xs font-semibold text-lumiora-dark truncate">${p.name}</span>
                            <span class="block text-[10px] text-gray-500">${p.code} &bull; ${formatPrice(p.price)}</span>
                        </span>
                    </button>
                    <button type="button" data-action="add" data-code="${p.code}" aria-label="Add ${p.name} to cart"
                            class="w-8 h-8 flex-shrink-0 rounded-full bg-lumiora-btn hover:bg-lumiora-btnHover text-lumiora-dark text-xs">
                        <i class="fas fa-cart-plus"></i>
                    </button>
                </div>
            `).join('') + `
                <button type="button" data-action="all" class="w-full text-center text-xs font-semibold text-lumiora-accent hover:underline py-2">
                    See all ${matches.length} result${matches.length === 1 ? '' : 's'} on the Products page
                </button>`;
        }
        box.classList.remove('hidden');
    }

    // Show results on every keystroke (this is the "appears automatically" part)
    input.addEventListener('input', showResults);
    input.addEventListener('focus', showResults);

    // Clicks inside the drop-down
    box.addEventListener('click', event => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const action = button.dataset.action;
        if (action === 'view') {
            openQuickView(button.dataset.code);
        } else if (action === 'add') {
            addToCart(button.dataset.code);
        } else if (action === 'all') {
            runFullSearch(input.value.trim());
        }
        if (action !== 'add') box.classList.add('hidden');
    });

    // Pressing Enter
    form.addEventListener('submit', event => {
        event.preventDefault();
        runFullSearch(input.value.trim());
        box.classList.add('hidden');
    });

    // Click outside or press Escape -> close the drop-down
    document.addEventListener('click', event => {
        if (!wrap.contains(event.target)) box.classList.add('hidden');
    });
    input.addEventListener('keydown', event => {
        if (event.key === 'Escape') box.classList.add('hidden');
    });
}

// If we're already on the Products page, filter it. Otherwise go there.
function runFullSearch(term) {
    if (typeof window.applyProductSearch === 'function') {
        window.applyProductSearch(term);
    } else {
        window.location.href = 'products.html?search=' + encodeURIComponent(term);
    }
}

/* ----------------------------------------------------------
   5. FORM VALIDATION
   Add  data-rules="required|email|min:10"  to any input and
   call validateForm(form). Rules available:
     required   - cannot be empty
     fullname   - letters, spaces, ' . - only (min 2 characters)
     email      - must look like name@domain.co.za
     phone      - South African number (073 697 5923 / +27736975923)
     min:N      - at least N characters
   Empty optional fields are skipped (only "required" flags them).
   ---------------------------------------------------------- */
function checkRule(rule, value) {
    const [name, argument] = rule.split(':');
    const text = value.trim();

    switch (name) {
        case 'required':
            return text !== '' ? '' : 'This field is required.';
        case 'fullname':
            return /^[A-Za-zÀ-ÿ'’.\- ]{2,}$/.test(text) ? '' : 'Please enter your name (letters only, at least 2 characters).';
        case 'email':
            return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(text) ? '' : 'Enter a valid email address, e.g. name@example.co.za.';
        case 'phone': {
            const digits = text.replace(/[\s\-()]/g, '');
            return /^(\+27|27|0)\d{9}$/.test(digits) ? '' : 'Enter a valid South African number, e.g. 073 697 5923.';
        }
        case 'min':
            return text.length >= Number(argument) ? '' : `Please enter at least ${argument} characters.`;
        default:
            return '';
    }
}

function validateField(field) {
    const rules = (field.dataset.rules || '').split('|').filter(Boolean);
    const isEmpty = field.value.trim() === '';
    let error = '';

    for (const rule of rules) {
        // An empty field is only an error if it is "required"
        if (isEmpty && rule !== 'required') continue;
        error = checkRule(rule, field.value);
        if (error) break;
    }

    showFieldError(field, error);
    return error === '';
}

function showFieldError(field, message) {
    // One error paragraph per field, created the first time it's needed
    if (!field._errorEl) {
        field._errorEl = document.createElement('p');
        field._errorEl.className = 'field-error';
        field._errorEl.setAttribute('role', 'alert');
        field.insertAdjacentElement('afterend', field._errorEl);
    }
    field._errorEl.textContent = message;
    field.classList.toggle('input-invalid', message !== '');
    field.setAttribute('aria-invalid', message !== '' ? 'true' : 'false');
}

// Checks every field in a form; returns true only if all are valid
function validateForm(form) {
    let firstBad = null;
    form.querySelectorAll('[data-rules]').forEach(field => {
        if (!validateField(field) && !firstBad) firstBad = field;
    });
    if (firstBad) firstBad.focus();
    return firstBad === null;
}

// Check each field when the visitor leaves it, and re-check while fixing it
function enableLiveValidation(form) {
    form.querySelectorAll('[data-rules]').forEach(field => {
        field.addEventListener('blur', () => validateField(field));
        field.addEventListener('input', () => {
            if (field.classList.contains('input-invalid')) validateField(field);
        });
    });
}

/* ----------------------------------------------------------
   6. NEWSLETTER SIGN-UP (the "Glow Club" box above the footer)
   The About page has no JavaScript, so its form sends the email
   to index.html?newsletter=... and we pick it up here.
   ---------------------------------------------------------- */
function subscribeEmail(email) {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
        showToast('Please enter a valid email address to subscribe.', 'error');
        return false;
    }
    try {
        const list = JSON.parse(localStorage.getItem('lumiora_newsletter') || '[]');
        if (!list.includes(email.trim().toLowerCase())) list.push(email.trim().toLowerCase());
        localStorage.setItem('lumiora_newsletter', JSON.stringify(list));
    } catch (error) { /* ignore storage problems */ }

    showToast('Welcome to the Lumiora Glow Club! Newsletter subscribed.', 'success');
    return true;
}

function initNewsletter() {
    document.querySelectorAll('form[data-newsletter]').forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            const emailInput = form.querySelector('input[type="email"]');
            if (subscribeEmail(emailInput.value)) form.reset();
        });
    });

    // Arrived from the About page form?
    const params = new URLSearchParams(window.location.search);
    if (params.has('newsletter')) {
        subscribeEmail(params.get('newsletter'));
        history.replaceState(null, '', window.location.pathname);
    }
}

/* ----------------------------------------------------------
   SHARED POP-UPS
   The cart drawer, quick view, project pop-up and toast area are
   identical on every page, so they are added to the page here
   instead of being copied into each HTML file.
   ---------------------------------------------------------- */
function injectSharedUI() {
    const holder = document.createElement('div');
    holder.innerHTML = `
        <!-- Shopping Cart Drawer -->
        <div id="cartDrawer" class="fixed inset-0 z-50 overflow-hidden hidden">
            <div class="absolute inset-0 bg-black/40 backdrop-blur-sm" onclick="toggleCartDrawer()"></div>
            <div class="fixed inset-y-0 right-0 max-w-full flex pl-10">
                <div class="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
                    <div>
                        <div class="p-6 bg-lumiora-cream flex justify-between items-center border-b border-lumiora-rose/20">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-shopping-bag text-lumiora-accent"></i>
                                <h3 class="font-bold text-lumiora-dark">Your Shopping Bag</h3>
                            </div>
                            <button onclick="toggleCartDrawer()" class="text-gray-400 hover:text-gray-600">
                                <i class="fas fa-times text-lg"></i>
                            </button>
                        </div>

                        <div id="cartItemsContainer" class="p-6 overflow-y-auto max-h-[60vh] space-y-4">
                            <!-- Dynamic items rendered via JS -->
                        </div>
                    </div>

                    <div class="p-6 border-t border-gray-100 bg-gray-50 space-y-4">
                        <div class="flex justify-between text-sm font-semibold text-lumiora-dark">
                            <span>Subtotal</span>
                            <span id="cartSubtotal">R0.00</span>
                        </div>
                        <p class="text-[11px] text-gray-400">Taxes and shipping calculated at checkout in South Africa.</p>
                        <button onclick="checkoutCart()" class="w-full py-3.5 bg-lumiora-accent hover:bg-lumiora-btn text-white hover:text-lumiora-dark font-bold rounded-xl shadow transition">
                            Proceed to Checkout
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick View Product Detail Modal -->
        <div id="quickViewModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
            <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" onclick="closeQuickView()"></div>
            <div class="relative bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl z-10 border border-lumiora-rose/30 max-h-[90vh] overflow-y-auto">
                <button onclick="closeQuickView()" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-lg">
                    <i class="fas fa-times"></i>
                </button>
                <div id="quickViewContent" class="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
                    <!-- Content injected by JS -->
                </div>
            </div>
        </div>

        <!-- Project Timeline & Proposal Reference Modal -->
        <div id="projectModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
            <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" onclick="toggleProjectModal()"></div>
            <div class="relative bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl z-10 border border-lumiora-rose/30 max-h-[90vh] overflow-y-auto">
                <button onclick="toggleProjectModal()" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-lg">
                    <i class="fas fa-times"></i>
                </button>
                <div class="space-y-6">
                    <div>
                        <span class="text-xs font-semibold text-lumiora-accent uppercase">WEDE5020 POE Part 1</span>
                        <h3 class="text-2xl font-bold text-lumiora-dark">Lumiora Project Details & Budget Summary</h3>
                        <p class="text-xs text-gray-500">Student ID: ST10533739 | Author: Sandy Mpe</p>
                    </div>

                    <!-- Timelines Table -->
                    <div>
                        <h4 class="font-bold text-sm text-lumiora-dark mb-2">10-Week Project Timelines</h4>
                        <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px] text-center">
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W1: Proposal</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W2: Research</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W3: Wireframes</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W4: HTML</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W5: CSS</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W6: JavaScript</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W7: Testing</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W8: Improvements</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W9: Docs</div>
                            <div class="bg-lumiora-cream p-2 rounded-lg border border-lumiora-rose/20">W10: Submission</div>
                        </div>
                    </div>

                    <!-- Estimated Budget -->
                    <div>
                        <h4 class="font-bold text-sm text-lumiora-dark mb-2">Estimated Budget Breakdown</h4>
                        <div class="bg-gray-50 p-4 rounded-2xl border border-gray-200 text-xs space-y-1.5">
                            <div class="flex justify-between"><span>Domain Registration:</span><span>R150</span></div>
                            <div class="flex justify-between"><span>Web Hosting (Shared 15GB):</span><span>R1 200</span></div>
                            <div class="flex justify-between"><span>Website Design:</span><span>R2 000</span></div>
                            <div class="flex justify-between"><span>Website Development:</span><span>R4 000</span></div>
                            <div class="flex justify-between"><span>Photography & Graphics:</span><span>R1 000</span></div>
                            <div class="flex justify-between"><span>Testing:</span><span>R500</span></div>
                            <div class="flex justify-between"><span>Annual Maintenance:</span><span>R1 500</span></div>
                            <div class="flex justify-between"><span>Marketing:</span><span>R2 000</span></div>
                            <div class="flex justify-between font-bold border-t border-gray-300 pt-2 text-lumiora-accent text-sm">
                                <span>Total Budget:</span><span>R12 350</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Toast Notification Container -->
        <div id="toastContainer" class="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 pointer-events-none" aria-live="polite"></div>
    `;
    document.body.appendChild(holder);
}

/* ----------------------------------------------------------
   START-UP: runs once the page has loaded
   ---------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
    injectSharedUI();

    // Header bag icon opens the drawer
    document.querySelectorAll('[data-cart-toggle]').forEach(button => {
        button.addEventListener('click', toggleCartDrawer);
    });

    updateCartUI();
    initHeaderSearch();
    initNewsletter();
    openProjectIfRequested();

    window.addEventListener('hashchange', openProjectIfRequested);

    // Keep the cart in sync if it changes in another browser tab
    window.addEventListener('storage', event => {
        if (event.key === CART_KEY) {
            cart = loadCart();
            updateCartUI();
        }
    });

    // Escape closes any open pop-up
    document.addEventListener('keydown', event => {
        if (event.key !== 'Escape') return;
        document.getElementById('cartDrawer').classList.add('hidden');
        closeQuickView();
        if (!document.getElementById('projectModal').classList.contains('hidden')) toggleProjectModal();
    });
});

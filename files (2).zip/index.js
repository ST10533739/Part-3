/* ==========================================================
   js/index.js  -  HOME PAGE ONLY
   1. Shows the featured products (with Add to Cart buttons)
   2. Fades sections in as the visitor scrolls (animation)
   Needs: products-data.js + common.js loaded first
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
    renderFeaturedProducts();
    startScrollReveal();
});

/* ---------- 1. Featured products ---------- */
function renderFeaturedProducts() {
    const container = document.getElementById('featuredProductsGrid');
    if (!container) return;

    // The first 3 products in products-data.js are the featured ones
    const featured = PRODUCTS.slice(0, 3);
    container.innerHTML = featured.map(product => productCardHTML(product)).join('');

    // These cards are created after page load, so mark them for the animation too
    container.querySelectorAll('article').forEach(card => card.setAttribute('data-reveal', ''));
}

/* ---------- 2. Scroll-reveal animation ----------
   Anything with a data-reveal attribute starts faint and slides
   up into view the first time it is scrolled onto the screen. */
function startScrollReveal() {
    const items = document.querySelectorAll('[data-reveal]');

    // Very old browsers: skip the animation, just show everything
    if (!('IntersectionObserver' in window)) return;

    const observer = new IntersectionObserver((entries, watcher) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                watcher.unobserve(entry.target);      // only animate once
            }
        });
    }, { threshold: 0.15 });

    items.forEach(item => {
        item.classList.add('reveal');
        observer.observe(item);
    });
}

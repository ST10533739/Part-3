/* ==========================================================
   js/contact.js  -  CONTACT PAGE ONLY
   - Validates the "Send Us a Direct Message" form
   - Counts characters in the message box
   - Saves the message and shows a confirmation
   Needs: products-data.js + common.js loaded first
   ========================================================== */

const MESSAGES_KEY = 'lumiora_messages';
const MAX_MESSAGE_LENGTH = 500;

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contactForm');
    const message = document.getElementById('contactMessage');

    enableLiveValidation(form);
    form.addEventListener('submit', handleContactSubmit);

    // Live character counter
    message.addEventListener('input', updateCharacterCount);
    updateCharacterCount();
});

function updateCharacterCount() {
    const message = document.getElementById('contactMessage');
    const counter = document.getElementById('messageCount');
    counter.textContent = `${message.value.length} / ${MAX_MESSAGE_LENGTH}`;
}

function handleContactSubmit(event) {
    event.preventDefault();
    const form = event.target;

    if (!validateForm(form)) {
        showToast('Please fix the highlighted fields.', 'error');
        return;
    }

    const entry = {
        date: new Date().toISOString(),
        name: form.elements['name'].value.trim(),
        email: form.elements['email'].value.trim(),
        subject: form.elements['subject'].value.trim(),
        message: form.elements['message'].value.trim()
    };

    try {
        const saved = JSON.parse(localStorage.getItem(MESSAGES_KEY) || '[]');
        saved.push(entry);
        localStorage.setItem(MESSAGES_KEY, JSON.stringify(saved));
    } catch (error) { /* storage unavailable - still show the confirmation */ }

    // Friendly on-page confirmation (name is inserted safely with textContent)
    document.getElementById('contactSuccessName').textContent = entry.name.split(' ')[0];
    document.getElementById('contactSuccess').classList.remove('hidden');

    showToast('Message sent! Thank you for contacting Lumiora Skincare.', 'success');
    form.reset();
    form.querySelectorAll('[data-rules]').forEach(field => showFieldError(field, ''));
    updateCharacterCount();
}
